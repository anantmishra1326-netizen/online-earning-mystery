ONLINE EARNING MYSTERY — STARTER ZIP

इस ZIP में responsive homepage, package cards, login/register form और शुरुआती member dashboard है।

पहले config.js खोलकर:
- url में Supabase Project URL डालें।
- publishableKey में Supabase की Publishable key डालें।
Supabase Dashboard में Project Connect या Settings > API Keys से ये values मिलेंगी।

सिर्फ Publishable key इस्तेमाल करें। Secret/service_role key, database password, या payment secret को browser files में कभी न डालें।

महत्वपूर्ण सीमाएं:
- यह अभी production-ready payment/earning system नहीं है।
- Payment gateway, webhook verification, refund workflow, wallet, earnings calculations और owner/admin controls अभी नहीं जुड़े हैं।
- Email confirmation ON होने पर registration के बाद profile insert flow को confirm-email/login के बाद server-safe तरीके से पूरा करना होगा; current SQL policies के साथ इसे launch से पहले सुधारना/जाँचना जरूरी है।
- सभी tables के RLS/grants और policies की security review और real-user tests जरूरी हैं।
- वास्तविक payment से पहले पैकेज के बदले स्पष्ट वास्तविक सेवा/उत्पाद, refund terms और लागू कानून/gateway terms की समीक्षा करें। केवल नए paying members जोड़ने पर referral income न बनाएं।

Netlify Drop: ZIP extract करके folder के root में index.html वाली files deploy करें। Upload करने से पहले config.js में URL/key डालें और test करें।

Official docs:
https://supabase.com/docs/guides/getting-started/api-keys
https://supabase.com/docs/guides/database/secure-data
https://docs.netlify.com/start/quickstarts/netlify-drop-quickstart/
