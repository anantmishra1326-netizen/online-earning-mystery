/* Put only your public Supabase Project URL and Publishable key here.
   NEVER use a secret key, service_role key, database password, or payment secret. */
window.OEM_CONFIG={url: "https://bbvcpytjenzzpgdjhkcd.supabase.co",publishableKey: "sb_publishable_qfUHwA82Liz988ZrLke9AQ_cTstU2ji"};